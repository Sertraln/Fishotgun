

import random
from shared.parsedata.fishlist import FishList
from shared.parsedata.fishing import FishingSessionData

def handle_start_fishing_request(client_socket):
    abondants = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]
    discrets = [14, 15, 16, 17, 18, 19]
    insaisissables = [13, 20, 21, 22, 23]

    chosen_ids = []
    for _ in range(4):
        rand = random.random()
        if rand < 0.60:
            chosen_ids.append(random.choice(abondants))
        elif rand < 0.90:
            chosen_ids.append(random.choice(discrets))
        else:
            chosen_ids.append(random.choice(insaisissables))

    # Création du paquet réseau contenant la session de jeu légitime
    packet = FishingSessionData(chosen_ids)
    encoded_packet = FishingSessionData.encode(packet)
    
    # Envoyez l'encoded_packet via votre système réseau (ex: client_socket.send)
    # client_socket.send(encoded_packet)